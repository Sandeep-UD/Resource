import csv
import requests
import json
import os
import sys

# ===============================
# Read Environment Variables
# ===============================

TOKEN = os.environ.get("GITHUB_TOKEN")
ENTERPRISE = os.environ.get("ENTERPRISE")

if not TOKEN:
    sys.exit("❌ ERROR: Please set the GITHUB_TOKEN environment variable.")

if not ENTERPRISE:
    sys.exit("❌ ERROR: Please set the ENTERPRISE environment variable.")

API_URL = f"https://api.github.com/scim/v2/enterprises/{ENTERPRISE}/Users"

HEADERS = {
    "Accept": "application/scim+json",
    "Authorization": f"Bearer {TOKEN}",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json"
}

# ===============================
# Provision User Function
# ===============================

def provision_user(row):
    payload = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "externalId": row["externalId"],
        "active": True,
        "userName": row["userName"],
        "name": {
            "formatted": row["formatted"],
            "familyName": row["familyName"],
            "givenName": row["givenName"]
        },
        "displayName": row["displayName"],
        "emails": [{
            "value": row["email"],
            "type": "work",
            "primary": True
        }],
        "roles": [{
            "value": row.get("role", "member"),
            "primary": False
        }]
    }

    try:
        response = requests.post(API_URL, headers=HEADERS, json=payload)

        print(f"➡ Provisioning {row['userName']} ({row['email']})")

        if response.status_code in (200, 201):
            print("   ✅ Success")
        elif response.status_code == 409:
            print("   ⚠ User already exists")
        else:
            print(f"   ❌ Failed ({response.status_code})")
            print("   Response:", response.text)

    except requests.exceptions.RequestException as e:
        print(f"   ❌ Request error: {e}")

# ===============================
# Main Execution
# ===============================

def main():
    if not os.path.exists("users.csv"):
        sys.exit("❌ users.csv file not found.")

    print(f"\n🚀 Starting SCIM provisioning for enterprise: {ENTERPRISE}\n")

    with open("users.csv", newline="", encoding="utf-8") as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            provision_user(row)

    print("\n🎉 Provisioning process completed.\n")

if __name__ == "__main__":
    main()
