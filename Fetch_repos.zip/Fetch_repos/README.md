# Fetch GitHub Repositories

This script fetches all repositories from a GitHub organization and exports their names and visibility to a CSV file.

## Prerequisites

- Python 3.x
- Required packages: `requests`, `python-dotenv`

Install dependencies:
```bash
pip install requests python-dotenv
```

## Setup

Create a `.env` file with the following variables:
```
GH_PAT=your_github_personal_access_token
GH_ORG=your_organization_name
```

## Usage

Run the script:
```bash
python fetch_repos.py
```

The script will:
1. Fetch all repositories from the organization
2. Export repository names and visibility to `github_repos.csv`
3. Log all operations to `logs/fetch_repos.log`

## Features

- ✅ Fetches all repositories from an organization
- ✅ Handles pagination automatically (100 repos per page)
- ✅ Automatic rate limit handling
- ✅ Detailed logging to file
- ✅ Simple CSV output with name and visibility
- ✅ Error handling and recovery

## Output

The script generates `github_repos.csv` with the following columns:

| Column | Description |
|--------|-------------|
| `Repository Name` | Repository name |
| `Visibility` | public, private, or internal |

## Token Permissions

The GitHub Personal Access Token must have:
- `repo` scope - Repository access
- `read:org` scope - Organization read access

## Logging

All operations are logged to `logs/fetch_repos.log`:
- Successful operations
- Rate limit warnings
- API errors
- Exceptions

The `logs/` directory is created automatically if it doesn't exist.

## Example Output

Console output:
```
CSV file saved successfully!
```

Or if rate limit is hit:
```
Rate limit exceeded. Waiting for 3600 seconds...
CSV file saved successfully!
```

## Sample CSV Output

```csv
Repository Name,Visibility
frontend-app,public
backend-api,private
mobile-app,private
documentation,public
internal-tools,internal
legacy-system,private
```

## Use Cases

- **Repository inventory**: Quick list of all organization repositories
- **Visibility audit**: Identify public vs private repositories
- **Compliance**: Document repository structure
- **Migration planning**: Export repository list before migration
- **Access review**: Verify which repositories are public
- **Documentation**: Create simple repository catalog

## Troubleshooting

### Permission Errors
- Ensure token has `repo` and `read:org` scopes
- Verify you have access to the organization
- Check token hasn't expired

### No Repositories Found
- Verify organization name is correct in `.env`
- Check you have access to view organization repositories
- Ensure organization has repositories

### Rate Limiting
- Script automatically handles rate limits
- Will pause and wait when limits are reached
- Check logs for rate limit messages

### Errors During Execution
- Check `logs/fetch_repos.log` for detailed error messages
- Verify internet connection
- Ensure GitHub API is accessible

## Rate Limits

- GitHub API limit: 5,000 requests/hour for authenticated users
- Script automatically waits when rate limit is reached
- Pagination fetches 100 repositories per request
- Large organizations may trigger rate limits

## Visibility Types

GitHub repository visibility:
- **public**: Accessible to everyone on the internet
- **private**: Only accessible to organization members with permission
- **internal**: Accessible to all organization members (Enterprise only)

## Related Scripts

For more detailed repository information, use:
- **Fetch repo details (Inventory)**: Comprehensive metrics including PRs, issues, branches, etc.

## Comparison with Other Scripts

| Feature | This Script | Fetch Repo Details |
|---------|-------------|-------------------|
| Speed | Fast | Slow (comprehensive) |
| Data | Name, Visibility | 17+ metrics |
| Use case | Quick inventory | Detailed audit |

## Security Considerations

- **CSV may reveal private repos**: Handle file appropriately
- **Don't commit to Git**: Add `*.csv` to `.gitignore`
- Keep `.env` file secure and never commit it

## Related Information

- Repository API: https://docs.github.com/en/rest/repos/repos
- Organization repos: https://docs.github.com/en/rest/repos/repos#list-organization-repositories
- Rate limiting: https://docs.github.com/en/rest/overview/resources-in-the-rest-api#rate-limiting

## Performance

- Very fast for small to medium organizations
- Processes 100 repositories per API call
- Typical execution time:
  - 10 repositories: < 1 second
  - 100 repositories: < 5 seconds
  - 1000 repositories: < 30 seconds
  - 5000 repositories: 2-3 minutes
