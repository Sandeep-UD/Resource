# Fetch GitHub Organization Users & Roles

This script fetches all members from one or more GitHub organizations with their details (name, email, role) and exports to a timestamped CSV file.

## Prerequisites

- Python 3.x
- Required packages: `requests`, `python-dotenv`

Install dependencies:
```bash
pip install requests python-dotenv
```

## Setup

Create a `.env` file with the following variables:
```
GH_PAT=your_github_personal_access_token
GH_ORG=org1,org2,org3
```

**Note**: You can specify multiple organizations separated by commas.

## Usage

Run the script:
```bash
python fetch_org_users_email_and_roles.py
```

The script will:
1. Fetch all members from each specified organization
2. Retrieve user details including name, email, and role
3. Export to timestamped CSV file `user_details_YYYYMMDD-HHMMSS.csv`
4. Display results in console

## Features

- ✅ Fetches users from multiple organizations
- ✅ Uses GitHub GraphQL API for efficient queries
- ✅ Retrieves full name, username, email, and role
- ✅ Handles pagination automatically
- ✅ Timestamped output files
- ✅ Error logging to `error_logs/` directory
- ✅ Console output for verification

## Output

The script generates `user_details_YYYYMMDD-HHMMSS.csv` with the following columns:

| Column | Description |
|--------|-------------|
| `organization_name` | Organization name |
| `full_name` | User's full name from profile |
| `user_name` | GitHub username |
| `user_github_handle` | GitHub handle (same as username) |
| `email` | User's email address |
| `role` | Organization role (ADMIN or MEMBER) |

## Token Permissions

The GitHub Personal Access Token must have:
- `read:org` scope - Read organization membership
- `user:email` scope - Access user email addresses
- `admin:org` scope - Required to see all members and roles

## Important Notes

### Email Availability
- **Email may be "N/A"**: If user hasn't made their email public
- Users control email visibility in their GitHub profile settings
- Private emails won't be returned by the API

### GraphQL API
- This script uses GitHub's GraphQL API (not REST)
- More efficient for fetching user details
- Handles pagination automatically (100 users per page)

### Multiple Organizations
- Specify multiple orgs separated by commas in `.env`
- All users from all orgs will be in one CSV
- Organization name column identifies which org each user belongs to

## Example Output

Console output:
```
Org: my-org, Full Name: John Doe, Username: johndoe, Handle: johndoe, Email: john@example.com, Role: ADMIN
Org: my-org, Full Name: Jane Smith, Username: janesmith, Handle: janesmith, Email: N/A, Role: MEMBER
Org: another-org, Full Name: Bob Developer, Username: bobdev, Handle: bobdev, Email: bob@company.com, Role: MEMBER
Details saved to user_details_20251119-103045.csv
```

## Sample CSV Output

```csv
organization_name,full_name,user_name,user_github_handle,email,role
my-org,John Doe,johndoe,johndoe,john@example.com,ADMIN
my-org,Jane Smith,janesmith,janesmith,N/A,MEMBER
my-org,Alice Developer,alicedev,alicedev,alice@example.com,MEMBER
another-org,Bob Developer,bobdev,bobdev,bob@company.com,ADMIN
another-org,Charlie Tester,charliet,charliet,charlie@company.com,MEMBER
```

## Use Cases

- **Organization audit**: Inventory all members and their roles
- **Access review**: Verify who has admin access
- **Compliance**: Document organization membership
- **Onboarding**: Create contact lists for new teams
- **Offboarding**: Identify members to remove
- **Communication**: Build email lists for team announcements
- **Migration**: Export members before moving to new organization

## Roles

GitHub organization roles:
- **ADMIN**: Organization owner or admin with full permissions
- **MEMBER**: Regular organization member

## Troubleshooting

### Email Shows "N/A"
- User hasn't made email public in GitHub profile
- Go to GitHub Settings → Emails → Uncheck "Keep my email addresses private"
- This is user-controlled, not a script issue

### Permission Errors
- Ensure token has `read:org`, `user:email`, and `admin:org` scopes
- Verify you're an organization admin or owner
- Check token hasn't expired

### No Users Found
- Verify organization name is correct in `.env`
- Check you have access to the organization
- Ensure organization has members

### GraphQL Errors
- Check error_logs/error.log for details
- Verify PAT is valid and has correct scopes
- Ensure organization names don't have spaces or special characters

## Error Logging

Errors are logged to `error_logs/error.log`:
- API request failures
- GraphQL query errors
- HTTP status codes and responses
- Timestamp for each error

Check this file if the script encounters issues.

## Security Considerations

### CSV Contains Personal Information
- **Contains names and emails**: Treat as personally identifiable information (PII)
- **Don't commit to Git**: Add `*.csv` to `.gitignore`
- **Secure storage**: Store in encrypted or restricted location
- **Limit distribution**: Only share with authorized personnel
- **GDPR/Privacy compliance**: Handle according to privacy regulations

### Token Security
- Never commit `.env` file
- Use tokens with minimum required scopes
- Rotate tokens regularly
- Revoke tokens when no longer needed

## Multiple Organizations

To fetch from multiple organizations, separate them with commas in `.env`:
```
GH_ORG=org1,org2,org3,org4
```

The script will:
- Query each organization sequentially
- Combine all results in one CSV
- Include organization name in each row
- Log errors per organization separately

## Rate Limits

- GitHub GraphQL API has separate rate limits from REST
- Limit: 5,000 points per hour
- This query uses ~1 point per 100 users
- Multiple organizations count separately
- Script does not currently implement rate limit handling for GraphQL

## Related Information

- Organization members: https://docs.github.com/en/organizations/managing-membership-in-your-organization
- GraphQL API: https://docs.github.com/en/graphql
- Organization roles: https://docs.github.com/en/organizations/managing-peoples-access-to-your-organization-with-roles/roles-in-an-organization

## Privacy Considerations

- Only fetch user information you're authorized to access
- Follow your organization's data handling policies
- Be transparent with users about data collection
- Delete exports when no longer needed
- Comply with applicable privacy laws (GDPR, CCPA, etc.)

## Data Analysis Tips

After exporting, you can use the CSV to:
- Count admins vs members per organization
- Identify users without email addresses
- Create mailing lists for communication
- Audit admin access across organizations
- Plan access reviews and recertification
- Generate reports for compliance
