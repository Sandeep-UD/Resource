# Fetch GitHub Environment Reviewers

This script fetches environment protection rules and required reviewers from all repositories in an organization and exports the data to CSV.

## Prerequisites

- Python 3.x
- Required packages: `requests`, `python-dotenv`

Install dependencies:
```bash
pip install requests python-dotenv
```

## Setup

Create a `.env` file with the following variables:
```
GH_PAT=your_github_personal_access_token
GH_ORG=your_organization_name
```

## Usage

Run the script:
```bash
python fetch_envi_reviewers.py
```

The script will:
1. Fetch all repositories in the organization
2. Query each repository for configured environments
3. Extract environment protection rules and required reviewers
4. Export all data to `environment_reviewers.csv`

## Features

- ✅ Fetches all repositories in the organization
- ✅ Retrieves environment configurations and protection rules
- ✅ Extracts required reviewers (users and teams)
- ✅ Handles pagination automatically
- ✅ Automatic rate limit handling
- ✅ Comprehensive environment metadata
- ✅ Progress reporting during execution

## Output

The script generates `environment_reviewers.csv` with the following columns:

| Column | Description |
|--------|-------------|
| `repository` | Full repository name (org/repo) |
| `environment` | Environment name (e.g., production, staging) |
| `environment_id` | Unique environment identifier |
| `environment_url` | API URL for the environment |
| `created_at` | Environment creation timestamp |
| `updated_at` | Last update timestamp |
| `can_admins_bypass` | Whether admins can bypass protection rules |
| `wait_timer` | Wait timer in minutes before deployment |
| `deployment_branch_policy` | Branch protection policy (JSON format) |
| `type` | Protection rule type (required_reviewers) |
| `reviewer_id` | Reviewer ID (user or team) |
| `reviewer_login` | Reviewer username or team slug |
| `reviewer_name` | Reviewer display name |
| `reviewer_type` | Reviewer type (User or Team) |

## Token Permissions

The GitHub Personal Access Token must have:
- `repo` scope - Repository access
- `admin:org` scope - Organization repository access

## Important Notes

### Environment Protection Rules
- **Required Reviewers**: Users or teams that must approve deployments
- **Wait Timer**: Delay before deployment can proceed
- **Admin Bypass**: Whether organization admins can bypass reviews
- **Branch Policy**: Which branches can deploy to the environment

### Reviewer Types
- **User**: Individual GitHub users
- **Team**: GitHub teams within the organization

### Multiple Reviewers
- Each reviewer gets a separate row in the CSV
- Environments without reviewers show "None" in reviewer columns
- Multiple protection rules are all extracted

## Example Output

```
[+] Fetching repositories...
[+] Total repositories fetched: 45
[~] Processing: my-org/frontend-app
[~] Processing: my-org/backend-api
[~] Processing: my-org/mobile-app
[✓] Done. Output saved to environment_reviewers.csv
```

## Sample CSV Output

```csv
repository,environment,environment_id,environment_url,created_at,updated_at,can_admins_bypass,wait_timer,deployment_branch_policy,type,reviewer_id,reviewer_login,reviewer_name,reviewer_type
my-org/backend-api,production,12345,https://api.github.com/...,2024-01-15T10:30:00Z,2024-11-10T14:20:00Z,false,30,"{""protected_branches"": true}",required_reviewers,67890,john-doe,John Doe,User
my-org/backend-api,production,12345,https://api.github.com/...,2024-01-15T10:30:00Z,2024-11-10T14:20:00Z,false,30,"{""protected_branches"": true}",required_reviewers,11111,platform-team,Platform Team,Team
my-org/frontend-app,staging,23456,https://api.github.com/...,2024-02-20T09:15:00Z,2024-10-05T16:45:00Z,true,0,"",required_reviewers,None,None,None,None
```

## Use Cases

- **Audit reviewers**: Inventory who can approve deployments
- **Compliance**: Document approval workflows for security audits
- **Policy review**: Verify environment protection configurations
- **Team planning**: Understand reviewer responsibilities across repos
- **Migration**: Export reviewer settings for recreation in new org

## Troubleshooting

### No Environments Found
- Verify repositories have environments configured
- Check repository settings → Environments
- Environments are only available on certain GitHub plans

### Empty Reviewer Fields
- Environment may not have required reviewers configured
- Shows "None" for environments without protection rules
- This is normal for development/testing environments

### Permission Errors
- Ensure token has `repo` and `admin:org` scopes
- Verify organization access
- Check token hasn't expired

### Rate Limiting
- Script automatically handles rate limits
- Will pause and wait when limits are reached
- For large organizations, this may take several minutes

## Environment Protection Settings

### Common Configurations

**Production Environment**:
- Required reviewers: Platform/DevOps team
- Wait timer: 15-30 minutes
- Admin bypass: Disabled
- Protected branches only: true

**Staging Environment**:
- Required reviewers: Development team
- Wait timer: 0 minutes
- Admin bypass: Enabled
- Protected branches only: false

**Development Environment**:
- No reviewers required
- No wait timer
- Admin bypass: Enabled
- All branches allowed

## Related Information

- Environments: https://docs.github.com/en/actions/deployment/targeting-different-environments
- Protection rules: https://docs.github.com/en/actions/deployment/targeting-different-environments/using-environments-for-deployment
- Environment API: https://docs.github.com/en/rest/deployments/environments

## Rate Limits

- GitHub API limit: 5,000 requests/hour for authenticated users
- Script automatically waits when rate limit is reached
- Large organizations may require extended processing time
- Each repository and environment requires separate API calls

## Data Analysis Tips

After exporting, you can use the CSV to:
- Count reviewers per environment
- Identify environments without protection
- Find users/teams with review responsibilities
- Audit wait timer configurations
- Compare policies across repositories
