# GitHub Repository Migration (Shell Script)

This Bash script automates the migration of GitHub repositories between organizations using the GitHub CLI (`gh gei`) extension.

## Prerequisites

- Bash shell (Linux, macOS, WSL, Git Bash on Windows)
- GitHub CLI (`gh`) installed and authenticated
- GitHub CLI GEI (GitHub Enterprise Importer) extension installed

### Install GitHub CLI

**Linux/WSL:**
```bash
sudo apt install gh
# or
brew install gh
```

**macOS:**
```bash
brew install gh
```

**Windows (Git Bash):**
Download from: https://cli.github.com/

### Install GEI Extension
```bash
gh extension install github/gh-gei
```

Verify installation:
```bash
gh gei --version
```

## Setup

1. Create a `.env` file with the following variables:
```
GH_SOURCE_PAT=your_source_github_pat
GH_PAT=your_target_github_pat
SOURCE=source_organization_name
DESTINATION=target_organization_name
```

2. Create a CSV file named `repos.csv` with the following format:
```csv
CURRENT-NAME,NEW-NAME
old-repo-name,new-repo-name
frontend-app,frontend-application
backend-api,backend-service
```

## CSV Format

| Column | Description |
|--------|-------------|
| `CURRENT-NAME` | Repository name in source organization |
| `NEW-NAME` | Repository name in target organization |

## Usage

Make the script executable:
```bash
chmod +x migrate_github_repos.sh
```

Run the script:
```bash
./migrate_github_repos.sh
```

The script will:
1. Load environment variables from `.env`
2. Read repository list from `repos.csv`
3. Migrate each repository using GitHub CLI GEI
4. Log all operations to `MigrationLog.txt`
5. Export results to `MigrationDetails.csv`
6. Save error logs to `logs/` directory

## Features

- ✅ Automated repository migration using GitHub GEI
- ✅ Batch processing from CSV file
- ✅ Detailed logging to text file
- ✅ Results exported to CSV with timestamps
- ✅ Individual error logs per repository
- ✅ Environment variable validation
- ✅ Duration tracking for each migration
- ✅ Handles repository renaming during migration
- ✅ Handles Windows line endings (CRLF)

## Output Files

### 1. `MigrationLog.txt`
Detailed log of all operations:
- Timestamp for each action
- Command outputs
- Errors and warnings
- Migration status

### 2. `MigrationDetails.csv`
Structured results with columns:
| Column | Description |
|--------|-------------|
| `SourceOrg` | Source organization name |
| `SourceRepo` | Source repository name |
| `TargetOrg` | Target organization name |
| `TargetRepo` | Target repository name |
| `Status` | Success or Failed |
| `StartTime` | Migration start timestamp |
| `EndTime` | Migration end timestamp |
| `TimeTakenSeconds` | Duration in seconds |

### 3. `logs/{repo-name}.log`
Individual error logs for failed migrations (created only on errors).

## Token Permissions

### Source Token (`GH_SOURCE_PAT`)
Required scopes:
- `repo` - Full repository access
- `read:org` - Organization read access

### Target Token (`GH_PAT`)
Required scopes:
- `repo` - Full repository access
- `admin:org` - Organization admin access (to create repositories)

## Important Notes

### GitHub GEI Tool
- Uses GitHub's official Enterprise Importer tool
- Migrates repository data, issues, pull requests, and more
- Handles large repositories efficiently
- Supports incremental migrations

### Repository Creation
- Target repositories are created automatically
- If target repository exists, migration may fail
- Repository names can be changed during migration

### Migration Contents
The GEI tool migrates:
- Git history and branches
- Issues and pull requests
- Releases and tags
- Wiki pages
- Repository settings (where applicable)
- **Note**: Does not migrate Actions secrets or variables

### Windows Compatibility
- Script handles Windows line endings (CRLF)
- Can run in Git Bash or WSL on Windows
- Use Unix-style line endings for best compatibility

## Example Output

Console output:
```
2025-11-19 10:30:15 [INFO] Loaded environment variables from .env
2025-11-19 10:30:16 [INFO] Migrating 'frontend-app' -> 'frontend-application'...
2025-11-19 10:35:42 [INFO] Migration result: Status=Success, Duration=326s
2025-11-19 10:35:43 [INFO] Migrating 'backend-api' -> 'backend-service'...
2025-11-19 10:40:18 [INFO] Migration result: Status=Success, Duration=275s
2025-11-19 10:40:18 [INFO] All repository migrations complete!
```

## Sample MigrationDetails.csv

```csv
SourceOrg,SourceRepo,TargetOrg,TargetRepo,Status,StartTime,EndTime,TimeTakenSeconds
source-org,frontend-app,target-org,frontend-application,Success,2025-11-19 10:30:16,2025-11-19 10:35:42,326
source-org,backend-api,target-org,backend-service,Success,2025-11-19 10:35:43,2025-11-19 10:40:18,275
source-org,old-project,target-org,archived-project,Failed,2025-11-19 10:40:19,2025-11-19 10:40:25,6
```

## Use Cases

- **Organization migration**: Move repositories to new organization
- **Repository consolidation**: Merge repositories from multiple orgs
- **Naming standardization**: Rename repositories during migration
- **Enterprise migration**: Migrate from GitHub.com to GitHub Enterprise
- **Backup and restore**: Create repository copies in different org

## Troubleshooting

### GEI Extension Not Found
```
gh: unknown command "gei"
```
Solution: Install GEI extension
```bash
gh extension install github/gh-gei
```

### Authentication Errors
- Verify tokens in `.env` file
- Ensure tokens haven't expired
- Check token scopes/permissions
- Re-authenticate GitHub CLI: `gh auth login`

### Permission Denied
```
bash: ./migrate_github_repos.sh: Permission denied
```
Solution: Make script executable
```bash
chmod +x migrate_github_repos.sh
```

### Missing Environment Variables
```
Required environment variables missing
```
Solution: Verify `.env` file contains all required variables:
- `GH_SOURCE_PAT`
- `GH_PAT`
- `SOURCE`
- `DESTINATION`

### CSV Parsing Issues
- Ensure CSV uses Unix line endings (LF)
- Script handles Windows line endings (CRLF) automatically
- Remove any extra spaces or special characters

### Repository Already Exists
- Target repository may already exist
- Use different name in `NEW-NAME` column
- Or delete existing repository in target org

### Migration Failures
- Check `logs/{repo-name}.log` for details
- Verify source repository is accessible
- Ensure sufficient permissions on both orgs
- Check network connectivity

## Performance Considerations

### Duration
- Small repos (< 100 MB): 2-5 minutes
- Medium repos (100 MB - 1 GB): 5-15 minutes
- Large repos (> 1 GB): 15+ minutes
- Time varies based on repository size and history

### Sequential Processing
- Repositories are migrated one at a time
- Consider breaking into smaller batches for many repos
- Monitor progress in console and log file

## Security Considerations

- **Never commit `.env` file**: Contains sensitive tokens
- **Protect log files**: May contain repository information
- **Token management**: Use tokens with minimum required scopes
- **Rotate tokens**: Change tokens after migration completes

## Best Practices

### Before Migration
1. Verify all repositories are accessible
2. Test with one repository first
3. Ensure target organization exists
4. Check available storage/seats in target org
5. Backup critical repositories

### During Migration
1. Monitor console output for errors
2. Don't interrupt the script (use Ctrl+C if needed)
3. Ensure stable network connection
4. Keep terminal window open

### After Migration
1. Verify repositories in target organization
2. Test cloning and basic operations
3. Update repository references in documentation
4. Notify team members of new locations
5. Archive or delete source repositories (if needed)

## Shell Compatibility

- **Bash**: Primary shell (recommended)
- **Zsh**: Compatible
- **Git Bash (Windows)**: Compatible
- **WSL**: Fully compatible
- **Sh**: May work but not guaranteed

## Line Ending Handling

Script automatically handles:
- Unix line endings (LF)
- Windows line endings (CRLF)
- Uses `tr -d '\r'` to clean CSV values

## Limitations

- Sequential processing only (not parallel)
- Cannot migrate Actions secrets/variables (do manually)
- Cannot migrate some organization-level settings
- May require manual adjustments for complex workflows
- Large repositories take significant time

## Related Information

- GitHub CLI: https://cli.github.com/
- GEI Extension: https://github.com/github/gh-gei
- Migration docs: https://docs.github.com/en/migrations/using-github-enterprise-importer
- GitHub Enterprise Importer: https://docs.github.com/en/migrations

## Alternative Approaches

For specific needs, consider:
- Manual repository transfer (Settings → Transfer ownership)
- GitHub Archive Program for backups
- Git mirroring for continuous sync
- PowerShell version for Windows-native execution
- Python version for cross-platform consistency

## Error Recovery

If migration fails:
1. Check error log in `logs/` directory
2. Verify tokens and permissions
3. Ensure target repo doesn't exist (or delete it)
4. Re-run script (will skip to next repo)
5. Edit CSV to remove successfully migrated repos
6. Contact GitHub support for complex issues

## Exit Codes

- `0` - Success
- `1` - Error (missing files, env vars, or migration failure)

The script uses `set -e` to exit on any command failure.
