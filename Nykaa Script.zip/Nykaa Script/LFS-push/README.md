# Git LFS Migration Tool

This script migrates Git Large File Storage (LFS) objects from source repositories to target repositories, typically used when moving repositories between organizations.

## Prerequisites

- Python 3.x
- Git installed and available in PATH
- Git LFS installed (`git lfs install`)
- Required packages: None (uses standard library)

Verify Git LFS is installed:
```bash
git lfs version
```

If not installed, download from: https://git-lfs.github.com/

## Setup

1. Create a `.env` file with the following variables:
```
Soucre-Access-Token=your_source_github_pat
Target-Access-Token=your_target_github_pat
```

**Note**: The variable name is `Soucre-Access-Token` (with typo) as used in the script.

2. Create a CSV file named `repos.csv` with the following format:
```csv
Source-Org,Target-Org,reponame
source-org-name,target-org-name,repo-with-lfs
source-org-name,target-org-name,another-lfs-repo
```

## CSV Format

| Column | Description |
|--------|-------------|
| `Source-Org` | Source organization name |
| `Target-Org` | Target organization name |
| `reponame` | Repository name (must exist in both orgs) |

## Usage

Run the script:
```bash
python push-lfs.py
```

The script will:
1. Clone each repository from the source organization
2. Fetch all LFS objects
3. Add the target repository as a remote
4. Push all LFS objects to the target repository
5. Clean up cloned directory
6. Log all operations to `migration_log.txt`

## Features

- ✅ Migrates Git LFS objects between organizations
- ✅ Processes multiple repositories from CSV
- ✅ Handles Windows long path issues
- ✅ Automatic directory cleanup after each repository
- ✅ Retry logic for cloning failures
- ✅ Detailed logging to file
- ✅ Color-coded console output
- ✅ Error handling and recovery

## Important Notes

### Prerequisites
- **Target repositories must already exist**: Script does not create repositories
- **Git LFS must be installed**: Both source and target repos must have LFS enabled
- **Sufficient disk space**: LFS objects are temporarily downloaded locally

### Token Permissions
Both source and target tokens must have:
- `repo` scope - Full repository access
- Access to LFS objects

### Repository State
- Source repository must have LFS objects configured
- Target repository should be empty or have matching LFS configuration
- Existing LFS objects in target will not be overwritten (Git LFS handles duplicates)

## Example Output

Console output:
```
Processing repository: design-assets
Cloning repository: https://***@github.com/source-org/design-assets.git
Fetching LFS objects...
Adding remote: https://***@github.com/target-org/design-assets.git
Pushing LFS files to target...
Successfully migrated: design-assets
Cleaned up existing directory: design-assets

Processing repository: video-library
Cloning repository: https://***@github.com/source-org/video-library.git
Fetching LFS objects...
Adding remote: https://***@github.com/target-org/video-library.git
Pushing LFS files to target...
Successfully migrated: video-library
Cleaned up existing directory: video-library

Migration process completed. Check migration_log.txt for details.
```

## Logging

All operations are logged to `migration_log.txt`:
- Repository processing steps
- Git command outputs
- Errors and warnings
- Success confirmations

Review this file for detailed information about the migration.

## Use Cases

- **Organization migration**: Moving repositories with LFS between organizations
- **Repository backup**: Copying LFS objects to backup location
- **Forking with LFS**: Ensuring LFS objects are in forked repositories
- **Multi-org sync**: Keeping LFS objects synchronized across organizations

## Troubleshooting

### Git LFS Not Installed
```
Error: git lfs command not found
```
- Install Git LFS from https://git-lfs.github.com/
- Run `git lfs install` after installation

### Clone Failures
- Script automatically retries with temporary directory
- Check network connection
- Verify source token has access to repository
- Ensure repository name is correct

### Long Path Issues (Windows)
- Script includes `core.longpaths=true` flag
- May need to enable long paths system-wide
- Run as administrator if needed

### Push Failures
- Verify target repository exists
- Check target token has write access
- Ensure target repository has LFS enabled
- Check disk space for LFS objects

### Permission Errors
- Verify both tokens have appropriate scopes
- Ensure access to both source and target organizations
- Check tokens haven't expired

## Windows Specific Notes

### Long Paths
The script handles Windows long path limitations:
- Uses `core.longpaths=true` Git config
- Removes read-only attributes before cleanup
- Alternative retry with temporary directories

### Git Configuration
May need to enable long paths globally:
```bash
git config --system core.longpaths true
```

Requires administrator privileges.

## Performance Considerations

### Disk Space
- Each repository is cloned temporarily with full LFS objects
- Large LFS files may require significant disk space
- Script cleans up after each repository to manage space

### Time
- Duration depends on LFS object sizes
- Large media files take longer to transfer
- Network speed affects clone and push times

### Batch Processing
- Processes repositories sequentially
- Consider breaking into smaller batches for large migrations
- Monitor disk space during execution

## Security Considerations

- **Tokens in .env**: Never commit `.env` file to version control
- **Log file**: May contain repository URLs (tokens are hidden)
- **Temporary clones**: Automatically cleaned up after processing
- **Token scopes**: Use minimum required permissions

## Best Practices

### Before Migration
1. Verify all repositories exist in target organization
2. Ensure Git LFS is installed and configured
3. Check available disk space
4. Test with a single repository first
5. Backup source repositories

### During Migration
1. Monitor console output for errors
2. Check `migration_log.txt` periodically
3. Ensure stable network connection
4. Don't interrupt during LFS push operations

### After Migration
1. Verify LFS objects in target repositories
2. Test cloning target repositories
3. Check LFS file integrity
4. Update repository references in documentation

## Common LFS Files

Typically tracked by Git LFS:
- **Media**: Videos, images, audio files
- **Design**: PSD, Sketch, Figma files
- **Data**: Large datasets, database dumps
- **Binaries**: Compiled executables, libraries
- **Archives**: ZIP, TAR, compressed files

## Verification

After migration, verify LFS objects in target:
```bash
git clone https://github.com/target-org/repo-name.git
cd repo-name
git lfs ls-files
git lfs fetch --all
```

## Related Information

- Git LFS: https://git-lfs.github.com/
- GitHub LFS: https://docs.github.com/en/repositories/working-with-files/managing-large-files
- LFS migration: https://docs.github.com/en/repositories/working-with-files/managing-large-files/moving-a-file-in-your-repository-to-git-large-file-storage

## Limitations

- Does not create target repositories (must exist)
- Does not migrate repository settings or permissions
- Does not handle conflicts in target repository
- Sequential processing only (not parallel)
- Requires local disk space for temporary clones

## Alternative Approach

For very large LFS objects, consider:
- Using GitHub's repository transfer feature
- Migrating repositories without re-cloning
- Using `git lfs migrate` for optimization
- Breaking into smaller batches
