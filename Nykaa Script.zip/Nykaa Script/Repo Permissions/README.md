# GitHub Repository Permissions Management

This folder contains Python scripts for fetching and applying repository-level permissions for users across GitHub organizations.

## Scripts

1. **`fetch_repo_permissiosn.py`** - Fetches all repository collaborators and their permissions from a source organization
2. **`apply_repo_permission.py`** - Applies repository permissions to users in a target organization

## Prerequisites

- Python 3.x
- Required packages:
  ```
  requests
  python-dotenv
  ```

Install dependencies:
```bash
pip install requests python-dotenv
```

## Setup

Create a `.env` file in this directory with the following variables:

```env
# For fetching permissions (source)
GH_PAT=your_source_github_token
GH_ORG=source-organization-name

# For applying permissions (target)
TARGET_GH_PAT=your_target_github_token
TARGET_GH_ORG=target-organization-name
```

**Important:** Add `.env` to your `.gitignore` to prevent exposing tokens.

## Script 1: Fetch Repository Permissions

### Purpose
Exports all direct collaborator permissions across all repositories in a source organization to a CSV file.

### Usage

```bash
python fetch_repo_permissiosn.py
```

### Features

- Fetches all repositories from the source organization
- Retrieves direct collaborators for each repository (excludes team-based permissions)
- Gets precise permission level for each user
- Normalizes permissions to GitHub API format (pull/push/maintain/triage/admin)
- Exports to `user_repo_permission.csv` with mapping columns for target organization
- Handles pagination automatically
- Includes rate limit handling
- Comprehensive logging to `repo-permissions.log` and console

### Output Format

CSV file: `user_repo_permission.csv`

| Column | Description |
|--------|-------------|
| Source Organization | Original organization name |
| Source Repository | Repository name in source org |
| Username | GitHub username |
| Original Permission | Raw permission from API (read/write/admin/maintain/triage) |
| Normalized Permission | API-compatible format (pull/push/admin/maintain/triage) |
| Target Organization | Destination organization (from .env or defaults to source) |
| Target Repository | Destination repository name (same as source) |
| EMU User | Empty column for manual EMU username mapping |

### Permission Normalization

The script normalizes permissions as follows:
- `read` → `pull`
- `write` → `push`
- `admin` → `admin`
- `maintain` → `maintain`
- `triage` → `triage`

### Token Requirements

**Required scopes for `GH_PAT`:**
- `repo` (full control of private repositories)
- `read:org` (read organization data)

## Script 2: Apply Repository Permissions

### Purpose
Applies repository permissions from the CSV file to a target organization. Supports EMU (Enterprise Managed Users) username mapping.

### Usage

1. Run the fetch script first to generate `user_repo_permission.csv`
2. (Optional) Fill in the "EMU User" column if migrating to an EMU organization
3. Run the apply script:

```bash
python apply_repo_permission.py
```

### Features

- Reads permissions from `user_repo_permission.csv`
- Validates repository and user existence before applying permissions
- Checks existing permissions to avoid unnecessary API calls
- Supports EMU username mapping (classic → EMU conversion)
- Skips rows with unmapped EMU users
- Permission hierarchy awareness (doesn't downgrade existing higher permissions)
- Comprehensive error handling and validation
- Detailed logging to `apply-permissions.log` and console
- Rate limit handling

### EMU User Mapping

For migrations to EMU organizations, manually populate the "EMU User" column:
- Leave blank or mark as "UNMAPPED" to skip that user
- Provide the EMU username (e.g., `john_doe_org` for classic user `john_doe`)

Example CSV after mapping:
```csv
Source Organization,Source Repository,Username,Original Permission,Normalized Permission,Target Organization,Target Repository,EMU User
source-org,repo1,john_doe,write,push,target-emu-org,repo1,john_doe_mycompany
source-org,repo2,jane_smith,admin,admin,target-emu-org,repo2,jane_smith_mycompany
source-org,repo3,unmapped_user,read,pull,target-emu-org,repo3,UNMAPPED
```

### Permission Levels

Supports all GitHub permission levels with hierarchy:
1. **read** (pull) - Clone and pull
2. **triage** - Read + manage issues/PRs (no code changes)
3. **write** (push) - Read + Triage + push commits
4. **maintain** - Write + manage repository settings (no destructive actions)
5. **admin** - Full administrative access

The script recognizes both API formats (`pull`/`push`) and human-readable formats (`read`/`write`).

### Permission Behavior

- **Permission Hierarchy Check**: If a user already has a higher permission level than specified in CSV, the script will NOT downgrade it
- **Exact Match**: If the user already has the exact permission, the script skips the API call
- **Upgrade**: If the user has a lower permission or no permission, the script applies the new permission

### Token Requirements

**Required scopes for `TARGET_GH_PAT`:**
- `repo` (full control of private repositories)
- `admin:org` (required to add collaborators to organization repositories)

### Validation Checks

The script performs the following validations:
- ✅ Repository exists in target organization
- ✅ User exists on GitHub
- ✅ User has existing permission (checks current level)
- ✅ EMU User mapping is provided (skips if unmapped)
- ✅ Required CSV columns are present

## Important Notes

### Affiliation Type
Both scripts work with **direct collaborators** only. Users who have access via team membership are NOT included. To manage team-based permissions, use the Teams scripts in the `../Teams/` folder.

### Rate Limiting
GitHub API has rate limits (5,000 requests/hour for authenticated requests). Both scripts:
- Monitor rate limit headers
- Automatically wait when limit is reached
- Display warnings in logs

For large organizations (100+ repos with many collaborators), the scripts may take considerable time.

### Security Best Practices

1. **Never commit tokens** - Always use `.env` files and add them to `.gitignore`
2. **Use fine-grained tokens** when possible with minimal required scopes
3. **Rotate tokens** regularly, especially after migrations
4. **Audit permissions** after applying them using GitHub's audit log
5. **Test with a few repositories** first before bulk operations

### Dry Run Testing

Before applying permissions to production:
1. Comment out the `add_user_permission()` call in `apply_repo_permission.py`
2. Run the script to see what would be applied (check logs)
3. Verify the actions are correct
4. Uncomment and run for real

## Example Workflow

### Scenario: Migrating repository permissions to EMU organization

```bash
# Step 1: Fetch permissions from source organization
python fetch_repo_permissiosn.py

# Step 2: Edit user_repo_permission.csv
# Map classic usernames to EMU usernames in the "EMU User" column

# Step 3: Apply permissions to target organization
python apply_repo_permission.py

# Step 4: Review logs
# Check apply-permissions.log for any errors or skipped users
```

### Expected Output

```
2025-01-15 10:00:00 - INFO - Fetched 50 repositories for organization 'source-org'.
2025-01-15 10:05:00 - INFO - Data written to user_repo_permission.csv with 150 permission entries
2025-01-15 10:05:00 - INFO - Script execution completed.

2025-01-15 10:10:00 - INFO - Set john_doe_mycompany permission to push on target-org/repo1.
2025-01-15 10:10:01 - INFO - Set jane_smith_mycompany permission to admin on target-org/repo2.
2025-01-15 10:10:02 - WARNING - Skipping row 45: No EMU User mapping for unmapped_user
```

## Troubleshooting

### "TARGET_GITHUB_TOKEN not found in .env file"
- Ensure your `.env` file has `TARGET_GH_PAT` defined
- Check the `.env` file is in the same directory as the script

### "Failed to fetch repos: 401"
- Token is invalid or expired
- Regenerate the token in GitHub Settings → Developer settings → Personal access tokens
- Ensure token has required scopes

### "Failed to fetch repos: 404"
- Organization name is incorrect
- Token doesn't have access to the organization
- For EMU orgs, ensure you're using an EMU user token

### "Failed to set [user] permission on [org]/[repo]: 403"
- Token lacks `admin:org` scope
- User may not be a member of the organization (invite them first)
- Repository may have branch protection or security rules preventing changes

### "Skipping row: No EMU User mapping"
- The "EMU User" column is empty or marked as "UNMAPPED"
- Fill in the EMU username or acknowledge the user should be skipped

### "CSV file 'user_repo_permission.csv' not found"
- Run `fetch_repo_permissiosn.py` first to generate the CSV
- Ensure you're running the script from the correct directory

### Rate Limit Issues
- Wait for the automatic rate limit reset (script will wait automatically)
- Use a GitHub App token for higher rate limits (15,000/hour)
- Split the CSV into smaller batches if needed

## Use Cases

1. **Organization Migration** - Transfer permissions when migrating to a new GitHub organization
2. **EMU Migration** - Map classic users to EMU users during Enterprise Managed Users adoption
3. **Permission Audit** - Export and review all repository permissions across the organization
4. **Disaster Recovery** - Backup permissions before making bulk changes, restore if needed
5. **Compliance Reporting** - Generate reports of who has access to which repositories
6. **Repository Restructuring** - Reapply permissions after reorganizing repositories
7. **Bulk Permission Updates** - Modify CSV and reapply to update permissions for multiple users

## Related Scripts

- **`../Provision users to repo/`** - Similar functionality but with different CSV format and focus on EMU provisioning
- **`../Teams/`** - Manage team-based repository access (different from direct collaborators)
- **`../Add users to org with role/`** - Invite users to organization with specific roles
- **`../Fetch_GitHub_Org_Users_roles/`** - Export all organization members and their roles

## Logs

Both scripts generate detailed logs:
- **`repo-permissions.log`** - Fetch script output
- **`apply-permissions.log`** - Apply script output

Logs include:
- Timestamp for each operation
- Success/failure status
- Error messages with details
- Rate limit warnings
- Summary statistics

## Summary

| Metric | fetch_repo_permissiosn.py | apply_repo_permission.py |
|--------|---------------------------|--------------------------|
| **Purpose** | Export permissions | Apply permissions |
| **Input** | .env configuration | user_repo_permission.csv |
| **Output** | user_repo_permission.csv | Log files |
| **Token** | GH_PAT | TARGET_GH_PAT |
| **Scope** | repo, read:org | repo, admin:org |
| **Log File** | repo-permissions.log | apply-permissions.log |
| **Validation** | None (export only) | Repo/user existence, permission levels |

---

**Note:** These scripts manage **direct collaborator** permissions only. Team-based access requires separate management through the GitHub Teams API.
