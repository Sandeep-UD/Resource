# Fetch GitHub Actions Runners

This script fetches information about GitHub Actions self-hosted runners from all repositories in an organization and exports the data to CSV.

## Prerequisites

- Python 3.x
- Required packages: `requests`, `python-dotenv`

Install dependencies:
```bash
pip install requests python-dotenv
```

## Setup

Create a `.env` file with the following variables:
```
GH_PAT=your_github_personal_access_token
GH_ORG=your_organization_name
```

## Usage

Run the script:
```bash
python fetch_actions_runners.py
```

The script will:
1. Fetch all repositories in the organization
2. Query each repository for self-hosted runners
3. Export runner details to `github_action_runners.csv`

## Features

- ✅ Fetches all repositories in the organization
- ✅ Retrieves self-hosted runner information per repository
- ✅ Handles pagination automatically
- ✅ Automatic rate limit handling
- ✅ Exports detailed runner data to CSV
- ✅ Progress reporting during execution

## Output

The script generates `github_action_runners.csv` with the following columns:

| Column | Description |
|--------|-------------|
| `Repository` | Repository name |
| `Runner ID` | Unique runner identifier |
| `Runner Name` | Runner display name |
| `OS` | Operating system (Linux, Windows, macOS) |
| `Status` | Runner status (online, offline) |
| `Busy` | Whether runner is currently executing a job |
| `Labels` | Comma-separated list of runner labels |

## Token Permissions

The GitHub Personal Access Token must have:
- `repo` scope - Repository access
- `admin:org` scope - Organization access (if fetching org-level runners)

## Important Notes

### Self-Hosted Runners Only
- This script fetches **self-hosted runners** configured in repositories
- GitHub-hosted runners (ubuntu-latest, windows-latest, etc.) are not included
- Only shows runners that have been registered with repositories

### Runner Information
- **Status**: `online` (active) or `offline` (unavailable)
- **Busy**: `true` (running a job) or `false` (idle)
- **Labels**: Custom labels for targeting specific runners in workflows
- **OS**: The operating system the runner is installed on

### Repository Scope
- Scans all repositories in the organization
- Repositories without runners will be skipped
- Progress shown for each repository

## Example Output

```
🔍 Fetching repositories for org: my-org
✅ Found 45 repositories

📦 Repo: frontend-app
  No runners found.

📦 Repo: backend-api
  Runner ID: 123, Name: prod-runner-01, OS: Linux, Status: online

📦 Repo: mobile-app
  Runner ID: 456, Name: ios-builder, OS: macOS, Status: online
  Runner ID: 789, Name: android-builder, OS: Linux, Status: busy

✅ CSV export complete: github_action_runners.csv
```

## Sample CSV Output

```csv
Repository,Runner ID,Runner Name,OS,Status,Busy,Labels
backend-api,123,prod-runner-01,Linux,online,false,self-hosted, linux, production
mobile-app,456,ios-builder,macOS,online,false,self-hosted, macOS, ios
mobile-app,789,android-builder,Linux,online,true,self-hosted, linux, android
```

## Use Cases

- **Audit runners**: Inventory all self-hosted runners across repositories
- **Monitor status**: Check which runners are online/offline
- **Capacity planning**: Identify busy runners and workload distribution
- **Label management**: Review runner labels and configurations
- **Compliance**: Document runner infrastructure for security audits

## Troubleshooting

### No Runners Found
- Verify repositories have self-hosted runners configured
- Check if runners are properly registered
- GitHub-hosted runners won't appear in results

### Permission Errors
- Ensure token has `repo` and `admin:org` scopes
- Verify organization access
- Check token hasn't expired

### Rate Limiting
- Script automatically handles rate limits
- Will pause and wait when limits are reached
- For large organizations, this may take time

### Empty CSV
- Confirms no self-hosted runners are configured
- Check runner registration in repository settings
- Verify runners are connected and online

## Runner Labels

Common runner labels include:
- `self-hosted` - Indicates self-hosted runner
- OS labels: `linux`, `windows`, `macOS`
- Architecture: `x64`, `arm`, `arm64`
- Custom labels: Added during runner configuration

## Related Information

- Self-hosted runners: https://docs.github.com/en/actions/hosting-your-own-runners
- Runner API: https://docs.github.com/en/rest/actions/self-hosted-runners
- Managing runners: https://docs.github.com/en/actions/hosting-your-own-runners/managing-self-hosted-runners

## Rate Limits

- GitHub API limit: 5,000 requests/hour for authenticated users
- Script automatically waits when rate limit is reached
- Large organizations may take longer to process
