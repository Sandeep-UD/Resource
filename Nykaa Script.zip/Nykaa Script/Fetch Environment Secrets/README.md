# Fetch GitHub Environment Secrets

This script fetches the names of secrets configured in GitHub repository environments across an organization and exports them to CSV.

## Prerequisites

- Python 3.x
- Required packages: `requests`, `python-dotenv`

Install dependencies:
```bash
pip install requests python-dotenv
```

## Setup

Create a `.env` file with the following variables:
```
GH_PAT=your_github_personal_access_token
GH_ORG=your_organization_name
```

## Usage

Run the script:
```bash
python fetch_env_secrets.py
```

The script will:
1. Fetch all repositories in the organization
2. Query each repository for configured environments
3. List all secret names in each environment
4. Export data to `github_environment_secrets.csv`

## Features

- ✅ Fetches all repositories in the organization
- ✅ Retrieves all environments per repository
- ✅ Lists secret names from each environment
- ✅ Handles pagination automatically
- ✅ Automatic rate limit handling
- ✅ Progress reporting during execution
- ✅ Handles repositories without environments

## Output

The script generates `github_environment_secrets.csv` with the following columns:

| Column | Description |
|--------|-------------|
| `Repository` | Repository name (without org prefix) |
| `Environment` | Environment name (e.g., production, staging) |
| `Secret Name` | Name of the secret (value is not retrievable) |

## Token Permissions

The GitHub Personal Access Token must have:
- `repo` scope - Full repository access including secrets

## Important Notes

### Secret Values Not Included
- **GitHub API does not allow retrieving secret values** for security reasons
- This script only fetches **secret names**, not their values
- Secret values must be manually documented or retrieved from source

### Environment Secrets vs Repository Secrets
- This script fetches **environment-specific secrets** only
- Repository-level secrets (not tied to environments) are not included
- Organization-level secrets are not included

### Empty Environments
- Environments without secrets will show an empty row
- Repositories without environments are skipped
- This helps identify which environments exist but have no secrets

## Example Output

```
🔍 Fetching repositories for organization: my-org
✅ Found 45 repositories

📦 Repository: frontend-app
  🔐 Environment: production
  🔐 Environment: staging

📦 Repository: backend-api
  🔐 Environment: production
  🔐 Environment: development

📦 Repository: mobile-app
  (No environments found)

✅ Export completed: github_environment_secrets.csv
```

## Sample CSV Output

```csv
Repository,Environment,Secret Name
frontend-app,production,API_KEY
frontend-app,production,DATABASE_URL
frontend-app,production,SENTRY_DSN
frontend-app,staging,API_KEY
frontend-app,staging,DATABASE_URL
backend-api,production,DATABASE_PASSWORD
backend-api,production,JWT_SECRET
backend-api,production,REDIS_URL
backend-api,development,
```

## Use Cases

- **Audit secrets**: Inventory all environment secrets across repositories
- **Security review**: Identify which environments use secrets
- **Migration planning**: Document secrets before moving to new organization
- **Compliance**: Track secret usage for security audits
- **Cleanup**: Find unused or duplicate secrets
- **Documentation**: Create inventory of secret requirements

## Troubleshooting

### No Environments Found
- Verify repositories have environments configured
- Check repository settings → Environments
- Environments are only available on certain GitHub plans

### Permission Errors
- Ensure token has `repo` scope
- Verify you have access to repository secrets
- Check token hasn't expired
- Ensure you're an admin or have appropriate permissions

### Rate Limiting
- Script automatically handles rate limits
- Will pause and wait when limits are reached
- For large organizations, this may take several minutes

### Empty Secret Names
- Indicates environment exists but has no secrets configured
- This is normal for newly created environments
- Review if secrets are needed for that environment

## Secret Management Best Practices

After exporting secret names:
1. **Document values separately**: Keep actual secret values in secure vault
2. **Review necessity**: Remove unused secrets
3. **Standardize names**: Ensure consistent naming conventions
4. **Audit access**: Verify who can view/modify secrets
5. **Rotate regularly**: Plan secret rotation schedules
6. **Use same names**: Maintain consistency across environments when appropriate

## Security Considerations

- **CSV contains secret names**: Treat this file as sensitive
- **Don't commit to Git**: Add `*.csv` to `.gitignore`
- **Limit distribution**: Only share with authorized personnel
- **Secure storage**: Store export in encrypted location
- **Delete after use**: Remove CSV when no longer needed

## Related Information

- Environment secrets: https://docs.github.com/en/actions/security-guides/encrypted-secrets#creating-encrypted-secrets-for-an-environment
- Secrets API: https://docs.github.com/en/rest/actions/secrets
- Managing secrets: https://docs.github.com/en/actions/security-guides/encrypted-secrets

## Rate Limits

- GitHub API limit: 5,000 requests/hour for authenticated users
- Script automatically waits when rate limit is reached
- Each repository, environment, and secret list requires separate API calls
- Large organizations may require extended processing time

## Data Analysis Tips

After exporting, you can analyze the CSV to:
- Count secrets per environment
- Identify environments without secrets
- Find duplicate secret names across repos
- Compare production vs staging secret configurations
- Plan secret consolidation or cleanup
