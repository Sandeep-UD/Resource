# Fetch GitHub Environment Variables

This script fetches environment variables and their values from all repositories in an organization and exports them to CSV.

## Prerequisites

- Python 3.x
- Required packages: `requests`, `python-dotenv`

Install dependencies:
```bash
pip install requests python-dotenv
```

## Setup

Create a `.env` file with the following variables:
```
GH_PAT=your_github_personal_access_token
GH_ORG=your_organization_name
```

## Usage

Run the script:
```bash
python fetch_github_environments.py
```

The script will:
1. Fetch all repositories in the organization
2. Query each repository for configured environments
3. Retrieve all variables and their values from each environment
4. Export data to `github_environments_variables.csv`

## Features

- ✅ Fetches all repositories in the organization
- ✅ Retrieves all environments per repository
- ✅ Exports variable names **and values** (unlike secrets)
- ✅ Handles pagination automatically
- ✅ Automatic rate limit handling
- ✅ Progress reporting during execution
- ✅ Handles repositories without environments

## Output

The script generates `github_environments_variables.csv` with the following columns:

| Column | Description |
|--------|-------------|
| `Repository` | Repository name (without org prefix) |
| `Environment` | Environment name (e.g., production, staging) |
| `Variable Name` | Name of the variable |
| `Value` | Variable value (plain text) |

## Token Permissions

The GitHub Personal Access Token must have:
- `repo` scope - Full repository access including variables

## Important Notes

### Variables vs Secrets
- **Variables**: Values are readable via API ✅ (this script)
- **Secrets**: Values are NOT readable via API ❌ (see Fetch Environment Secrets script)
- Use variables for non-sensitive configuration data
- Use secrets for sensitive data like passwords and tokens

### Environment Variables
- This script fetches **environment-specific variables** only
- Repository-level variables (not tied to environments) are not included
- Organization-level variables are not included

### Empty Environments
- Environments without variables will show empty value columns
- This helps identify which environments exist but have no variables configured

## Example Output

```
🔍 Fetching repositories for organization: my-org
✅ Found 45 repositories

📦 Processing repo: frontend-app
  🌍 Environment: production
  🌍 Environment: staging

📦 Processing repo: backend-api
  🌍 Environment: production
  🌍 Environment: development

📦 Processing repo: mobile-app
  (No environments found)

✅ CSV export complete: github_environments_variables.csv
```

## Sample CSV Output

```csv
Repository,Environment,Variable Name,Value
frontend-app,production,API_URL,https://api.production.example.com
frontend-app,production,DEBUG_MODE,false
frontend-app,production,LOG_LEVEL,info
frontend-app,staging,API_URL,https://api.staging.example.com
frontend-app,staging,DEBUG_MODE,true
frontend-app,staging,LOG_LEVEL,debug
backend-api,production,DATABASE_HOST,db.prod.internal
backend-api,production,CACHE_TTL,3600
backend-api,development,DATABASE_HOST,localhost
backend-api,development,CACHE_TTL,60
```

## Use Cases

- **Configuration audit**: Review all environment configurations
- **Migration**: Export variables before moving to new organization
- **Documentation**: Create inventory of environment settings
- **Consistency check**: Compare variables across environments
- **Backup**: Keep record of variable configurations
- **Troubleshooting**: Debug environment-specific issues

## Troubleshooting

### No Environments Found
- Verify repositories have environments configured
- Check repository settings → Environments
- Environments are only available on certain GitHub plans

### Permission Errors
- Ensure token has `repo` scope
- Verify you have access to repository variables
- Check token hasn't expired
- Ensure you have appropriate repository permissions

### Rate Limiting
- Script automatically handles rate limits
- Will pause and wait when limits are reached
- For large organizations, this may take several minutes

### Empty Variable Values
- Some variables may intentionally have empty values
- Environments without variables will show empty rows
- Review if variables are needed for that environment

## Security Considerations

### Variables are NOT Secrets
- **Variable values are readable**: Anyone with repo access can see them
- **Don't store sensitive data**: Use secrets for passwords, tokens, API keys
- **CSV contains actual values**: Treat this file carefully
- **Limit distribution**: Only share with authorized personnel
- **Don't commit to Git**: Add `*.csv` to `.gitignore`

### When to Use Variables vs Secrets
Use **Variables** for:
- API endpoints and URLs
- Feature flags
- Build configuration
- Non-sensitive environment settings
- Debug/log levels

Use **Secrets** for:
- Passwords and credentials
- API keys and tokens
- Private keys
- Database connection strings with credentials
- OAuth secrets

## Related Information

- Environment variables: https://docs.github.com/en/actions/learn-github-actions/variables
- Variables vs secrets: https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions#using-secrets
- Variables API: https://docs.github.com/en/rest/actions/variables

## Rate Limits

- GitHub API limit: 5,000 requests/hour for authenticated users
- Script automatically waits when rate limit is reached
- Each repository, environment, and variable list requires separate API calls
- Large organizations may require extended processing time

## Data Analysis Tips

After exporting, you can analyze the CSV to:
- Compare production vs staging configurations
- Identify inconsistent variable names across repos
- Find missing variables in certain environments
- Document environment-specific settings
- Plan variable standardization
- Create templates for new repositories

## Migration Workflow

1. Export variables from source organization
2. Review and update values for target organization
3. Use the "Add environment variables" script to import
4. Verify configurations in GitHub UI
5. Test deployments with new variables
