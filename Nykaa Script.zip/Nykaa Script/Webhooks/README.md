# GitHub Webhooks Migration Tool

This Python script exports and imports GitHub repository webhooks between organizations, making it easy to migrate webhook configurations during repository migrations or reorganizations.

## Features

- **Export Webhooks** - Extract webhook configurations from source repositories
- **Import Webhooks** - Apply webhooks to target repositories
- **Duplicate Prevention** - Skips webhooks that already exist in target repositories
- **Active Webhook Filtering** - Only exports active webhooks (inactive ones are skipped)
- **CSV-Based Repository Mapping** - Process multiple repositories from CSV file
- **Comprehensive Reporting** - Detailed CSV report of migration results
- **Separate Authentication** - Independent tokens for source and target organizations
- **Detailed Logging** - Console output and file logging for troubleshooting

## Prerequisites

- Python 3.x
- Required packages:
  ```
  PyGithub
  python-dotenv
  ```

Install dependencies:
```bash
pip install PyGithub python-dotenv
```

## Setup

Create a `.env` file in the Webhooks directory:

```env
# Source organization configuration
GH_PAT=your_source_github_token
GH_ORG=source-organization-name

# Target organization configuration
TARGET_GH_PAT=your_target_github_token
TARGET_GH_ORG=target-organization-name

# Configuration files (optional - these are defaults)
REPOSITORIES_CSV=repositories.csv
WEBHOOKS_EXPORT_FILE=exported_webhooks.json
LOG_FILE=webhook_migration.log
CSV_REPORT_FILE=webhook_migration_report.csv
```

**Important:** Add `.env` to your `.gitignore` to protect your tokens.

## CSV File Format

Create `repositories.csv` (or filename specified in `REPOSITORIES_CSV`):

```csv
source_repo,target_repo
backend-api,backend-api
frontend-app,frontend-app
mobile-sdk,mobile-sdk-v2
```

**Columns:**
- **source_repo** - Repository name in source organization (no org prefix)
- **target_repo** - Repository name in target organization (can be different)

**Notes:**
- Repository names only, without organization prefix
- Source and target repo names can differ (useful for renamed repositories)
- Empty rows are automatically skipped

## Usage

The script has two operation modes:

### 1. Export Mode

Export webhooks from source organization repositories:

```bash
python migrate_webhooks.py export
```

**What happens:**
- Reads repository mappings from `repositories.csv`
- Connects to source organization using `GH_PAT`
- Fetches all active webhooks from each source repository
- Saves webhook configurations to `exported_webhooks.json`
- Logs all operations to `webhook_migration.log` and console

### 2. Import Mode

Import webhooks to target organization repositories:

```bash
python migrate_webhooks.py import
```

**What happens:**
- Reads webhook configurations from `exported_webhooks.json`
- Connects to target organization using `TARGET_GH_PAT`
- Checks for existing webhooks to avoid duplicates
- Creates webhooks in target repositories
- Generates `webhook_migration_report.csv` with detailed results
- Logs all operations to `webhook_migration.log` and console

## Webhook Configuration

Each exported webhook includes:

- **URL** - The webhook endpoint URL
- **Content Type** - `json` or `form` (application/json or application/x-www-form-urlencoded)
- **SSL Verification** - Whether to verify SSL certificates (insecure_ssl)
- **Events** - List of GitHub events that trigger the webhook
- **Active Status** - Whether the webhook is active (only active webhooks are exported)

**Note:** Webhook secrets are NOT exported for security reasons. You'll need to reconfigure secrets manually after import.

## Webhook Events

Common GitHub webhook events that may be migrated:

- `push` - Git pushes to repository
- `pull_request` - Pull request activity
- `issues` - Issue activity
- `issue_comment` - Comments on issues and pull requests
- `create` - Branch or tag creation
- `delete` - Branch or tag deletion
- `release` - Release published
- `deployment` - Deployment activity
- `deployment_status` - Deployment status updates
- `status` - Commit status changes
- `check_run` - Check run activity
- `check_suite` - Check suite activity
- And many more...

All configured events are preserved during migration.

## Output Files

### Exported Webhooks JSON

Location: `exported_webhooks.json` (or as specified in `WEBHOOKS_EXPORT_FILE`)

Structure:
```json
{
  "export_date": "2025-01-15 14:30:00",
  "source_org": "source-company",
  "target_org": "target-company",
  "repositories": {
    "backend-api": {
      "target_repo": "backend-api",
      "webhooks": [
        {
          "url": "https://example.com/webhook",
          "content_type": "json",
          "insecure_ssl": "0",
          "events": ["push", "pull_request"],
          "active": true
        }
      ]
    }
  }
}
```

### Migration Report CSV

Location: `webhook_migration_report.csv` (or as specified in `CSV_REPORT_FILE`)

Columns:
- **migration_date** - Timestamp of migration attempt
- **source_org** - Source organization name
- **source_repo** - Source repository name
- **target_org** - Target organization name
- **target_repo** - Target repository name
- **webhook_url** - Webhook endpoint URL
- **events** - Comma-separated list of webhook events
- **status** - `SUCCESS`, `FAILED`, or `SKIPPED`
- **reason** - Details about failure or skip reason (empty for success)

### Log File

Location: `webhook_migration.log` (or as specified in `LOG_FILE`)

Contains detailed execution logs:
- Timestamp for each operation
- Authentication status
- Repository access verification
- Webhook discovery and creation
- Success and error messages
- API responses for troubleshooting

## Token Requirements

### For Export (`GH_PAT`)

Required scopes:
- `repo` (full control of private repositories)
- `admin:repo_hook` (read repository webhooks)

### For Import (`TARGET_GH_PAT`)

Required scopes:
- `repo` (full control of private repositories)
- `admin:repo_hook` (write repository webhooks)

**Note:** If you only work with public repositories, you can use more limited scopes, but `admin:repo_hook` is always required for webhook access.

## Important Notes

### Webhook Secrets

**Security consideration:** Webhook secrets are NOT exported or migrated by this script.

After importing webhooks, you must:
1. Access each webhook in the target repository settings
2. Configure the secret manually
3. Save the webhook configuration

This is intentional to prevent exposing secrets in export files.

### Active Webhooks Only

The export process only captures **active** webhooks. Inactive/disabled webhooks are:
- Logged as "skipped inactive webhook"
- Not included in the export file
- Not migrated to target repositories

To migrate inactive webhooks, activate them before export.

### Duplicate Prevention

During import, the script:
- Checks if a webhook with the same URL already exists
- Skips creation if found
- Marks as "SKIPPED" in the migration report
- Does NOT update or modify existing webhooks

To force recreation, delete existing webhooks in target repo first.

### Repository Mapping

Source and target repository names can differ:
```csv
source_repo,target_repo
old-api-name,new-api-name
legacy-service,modern-service
```

This is useful when:
- Repositories have been renamed during migration
- Following new naming conventions
- Consolidating or splitting repositories

## Example Workflow

### Scenario: Migrate webhooks during organization migration

```bash
# ===== STEP 1: Prepare CSV file =====
# Create repositories.csv with source and target repo mappings
echo "source_repo,target_repo" > repositories.csv
echo "backend-api,backend-api" >> repositories.csv
echo "frontend-app,frontend-app" >> repositories.csv
echo "mobile-sdk,mobile-sdk" >> repositories.csv

# ===== STEP 2: Set up environment =====
# Create .env file with source and target credentials
# GH_PAT=ghp_source_token
# GH_ORG=source-company
# TARGET_GH_PAT=ghp_target_token
# TARGET_GH_ORG=target-company

# ===== STEP 3: Export webhooks from source =====
python migrate_webhooks.py export

# Review exported_webhooks.json to verify webhook configurations
# Check webhook_migration.log for any issues

# ===== STEP 4: Import webhooks to target =====
python migrate_webhooks.py import

# Review webhook_migration_report.csv for results
# Check webhook_migration.log for detailed information

# ===== STEP 5: Configure webhook secrets =====
# Manually add secrets to each webhook in target repositories via GitHub UI
```

### Expected Output

**Export output:**
```
2025-01-15 14:30:00 - INFO - Source GitHub authentication successful
2025-01-15 14:30:00 - INFO - Starting webhook export process...
2025-01-15 14:30:01 - INFO - Fetching repository: source-company/backend-api
2025-01-15 14:30:01 - INFO - Repository found: source-company/backend-api
2025-01-15 14:30:02 - INFO - Fetching webhooks from source-company/backend-api...
2025-01-15 14:30:02 - INFO - Found 2 webhook(s) in the repository.
2025-01-15 14:30:02 - INFO - Exported webhook: https://ci.example.com/webhook
2025-01-15 14:30:02 - INFO - Exported webhook: https://deploy.example.com/webhook
2025-01-15 14:30:02 - INFO - Exported 2 active webhooks from backend-api
2025-01-15 14:30:03 - INFO - Webhooks exported successfully to exported_webhooks.json
2025-01-15 14:30:03 - INFO - Total repositories processed: 3
```

**Import output:**
```
2025-01-15 14:35:00 - INFO - Target GitHub authentication successful
2025-01-15 14:35:00 - INFO - Starting webhook import process...
2025-01-15 14:35:00 - INFO - Import file created on: 2025-01-15 14:30:00
2025-01-15 14:35:01 - INFO - Importing 2 webhooks to backend-api
2025-01-15 14:35:02 - INFO - Successfully imported webhook: https://ci.example.com/webhook
2025-01-15 14:35:02 - INFO - Successfully imported webhook: https://deploy.example.com/webhook
2025-01-15 14:35:03 - INFO - Generating CSV migration report at webhook_migration_report.csv
2025-01-15 14:35:03 - INFO - CSV report generation complete.
2025-01-15 14:35:03 - INFO - Webhook import process finished.
```

## Troubleshooting

### "Missing required environment variables"
- Ensure `.env` file exists in the script directory
- Check that all required variables are set: `GH_PAT`, `GH_ORG`, `TARGET_GH_PAT`, `TARGET_GH_ORG`
- Verify there are no typos in variable names
- Ensure values are not empty or contain only whitespace

### "Source/Target GitHub authentication failed: Invalid or expired token"
- Token has expired (regenerate in GitHub Settings)
- Token lacks required scopes (needs `repo` and `admin:repo_hook`)
- Typo in token value in `.env` file
- Token was revoked or deleted

### "Could not find repository"
- Repository name is incorrect in CSV
- Repository doesn't exist in the specified organization
- Token doesn't have access to private repository
- Organization name is wrong in `.env` file

### "Failed to fetch webhooks from repository: 403"
- Token lacks `admin:repo_hook` scope
- User doesn't have admin access to repository
- Repository has webhook access restrictions
- Organization may have SAML SSO requiring token authorization

### "Export file not found: exported_webhooks.json"
- Run `python migrate_webhooks.py export` first
- Check if `WEBHOOKS_EXPORT_FILE` in `.env` points to correct file
- Verify export completed successfully (check log file)

### "Webhook already exists in target"
- Webhook with same URL already configured in target repository
- This is expected behavior to prevent duplicates
- Check migration report for details
- Delete existing webhook if you want to recreate it

### "Failed to import webhook: 422 Unprocessable Entity"
- Webhook URL may be invalid or unreachable
- Required webhook configuration is missing
- Webhook events may not be valid for the repository
- Target repository may have webhook limits reached

### "Missing required columns in CSV"
- CSV header must include `source_repo` and `target_repo`
- Check for typos in column names
- Ensure CSV uses comma separators
- Verify CSV file is properly formatted

### No webhooks found during export
- Source repositories may not have any webhooks configured
- All webhooks may be inactive (only active webhooks are exported)
- Token may not have permission to read webhooks
- Check repository webhook settings in GitHub UI

## Use Cases

1. **Organization Migration** - Transfer webhook configurations when moving repositories to new organization
2. **Repository Cloning** - Apply same webhook setup to multiple repositories
3. **Environment Setup** - Migrate webhooks from production to staging/development
4. **Disaster Recovery** - Backup and restore webhook configurations
5. **Multi-Region Deployment** - Replicate webhooks across different organization instances
6. **Repository Renaming** - Maintain webhooks during repository name changes
7. **CI/CD Migration** - Transfer build and deployment webhooks to new systems
8. **Testing Webhooks** - Export production webhooks to test environments

## Security Best Practices

1. **Token Management**
   - Never commit `.env` files or tokens to git
   - Use fine-grained personal access tokens when possible
   - Rotate tokens regularly after migrations
   - Revoke tokens immediately after completing migration
   - Use separate tokens for source and target (different organizations)

2. **Webhook Secrets**
   - Export file does NOT contain secrets (by design)
   - Store secrets securely (password manager, secrets vault)
   - Update secrets manually after migration
   - Use strong, unique secrets for each webhook
   - Rotate webhook secrets periodically

3. **Access Control**
   - Use minimum required token scopes
   - Limit token access to specific repositories if possible
   - Audit webhook configurations before and after migration
   - Review migration report for unexpected results
   - Verify webhooks are pointing to correct endpoints

4. **Export File Security**
   - Export files may contain sensitive endpoint URLs
   - Store export files securely
   - Delete export files after migration if not needed for backup
   - Don't share export files publicly
   - Consider encrypting export files if storing long-term

5. **Testing**
   - Test with a single repository first
   - Verify webhooks work in target repositories
   - Check webhook delivery logs in GitHub UI
   - Send test payloads to verify endpoints respond correctly
   - Monitor webhook activity after migration

## Limitations

- **Webhook Secrets** - Not exported or migrated (must be configured manually)
- **Webhook Delivery History** - Not migrated (fresh start in target repos)
- **Inactive Webhooks** - Not exported (activate before export if needed)
- **Organization Webhooks** - Only repository-level webhooks supported
- **Webhook Updates** - Cannot update existing webhooks (only create new ones)
- **Custom Headers** - Some advanced webhook configurations may not be fully supported
- **Webhook Pings** - No automatic ping/test after creation

## Related Scripts

- **`../Migration/`** - Migrate repositories themselves before migrating webhooks
- **`../Fetch_repos/`** - Generate list of repositories to include in CSV
- **`../Rulesets/`** - Migrate repository rulesets (separate from webhooks)
- **`../Add environment secrets/`** - Manage environment-level secrets and configurations

## Alternative Approaches

If this script doesn't meet your needs:

1. **Manual Configuration** - For small numbers of repositories/webhooks
2. **GitHub Terraform Provider** - Infrastructure as code approach
3. **GitHub CLI** - Custom scripting with `gh api` commands
4. **GitHub REST API directly** - For highly customized webhook management
5. **Third-party tools** - Specialized migration platforms

## Summary

| Feature | Details |
|---------|---------|
| **Purpose** | Export and import GitHub repository webhooks |
| **Operations** | `export`, `import` |
| **Input** | repositories.csv with source/target mappings |
| **Export Output** | exported_webhooks.json with webhook configurations |
| **Import Output** | webhook_migration_report.csv with migration results |
| **Secrets** | NOT migrated (manual configuration required) |
| **Duplicate Handling** | Skips webhooks that already exist |
| **Active Only** | Only exports active webhooks |
| **Tokens Required** | repo + admin:repo_hook scopes |
| **Authentication** | Separate tokens for source and target |

**Workflow:**
1. Prepare repositories.csv
2. Export webhooks from source → `python migrate_webhooks.py export`
3. Review exported_webhooks.json
4. Import webhooks to target → `python migrate_webhooks.py import`
5. Manually configure webhook secrets in target repositories
6. Test webhook deliveries

---

**Security Note:** Webhook secrets are intentionally NOT migrated to prevent exposure. Configure secrets manually after import through the GitHub UI or API with appropriate security measures.
